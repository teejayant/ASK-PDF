from pdf_reader import extract_text_from_pdf
from gemini_qa import get_gemini_response, get_pdf_summary, summarize_answer

path = input("PDF path: ")
with open(path, "rb") as f:
    text = extract_text_from_pdf(f)

print("\n[1] Summarize PDF\n[2] Ask a Question")
choice = input("Choose an option: ")

if choice == "1":
    print(get_pdf_summary(text))
elif choice == "2":
    question = input("Your Question: ")
    answer = get_gemini_response(text, question)
    summary = summarize_answer(answer)
    print("\nAnswer:\n", answer)
    print("\nSummary:\n", summary)

#run in terminal:
#python--version

#.\venv_311\Scripts\activate  -->activate virtual environment
# python cmd_app.py 
